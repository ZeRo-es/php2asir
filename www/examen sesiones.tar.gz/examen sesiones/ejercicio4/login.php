<form action="carrito.php" method="post">
    <input type="text" name="usuario"><br>
    <input type="submit" value="conectar">
</form>